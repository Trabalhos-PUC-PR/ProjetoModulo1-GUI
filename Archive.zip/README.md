# Vaulty
An CLI password vault made in python

**Vaulty is a secure, 100% offline password vault made with python, it has user authentication and AES-256 encryption**

### Dependencies:
 To run this project, you need to have installed:
 - [PyCryptoDome](https://pypi.org/project/pycryptodome/)

### How to run:
 - Clone this repository;  
 - Go to ```Vaulty/app/```;  
 - Run `main.py`;  
